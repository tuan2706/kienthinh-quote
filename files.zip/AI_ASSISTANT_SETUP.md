# Hướng dẫn bật AI Sales Assistant cho Kiên Thịnh Quote

Tính năng AI (viết mô tả sản phẩm, soạn email, viết lời mở đầu báo giá, viết điều khoản
thương mại, tóm tắt yêu cầu khách hàng) cần 1 bước thiết lập 1 lần duy nhất. Sau khi
xong, dùng mãi không cần làm lại.

**Vì sao cần bước này?** App chạy hoàn toàn trên trình duyệt (không có máy chủ riêng).
Nếu gọi thẳng tới AI từ trình duyệt, API key sẽ bị lộ ra cho bất kỳ ai xem được mã nguồn
trang. Cách an toàn là dùng 1 "cầu nối" nhỏ (Netlify Function) — đoạn code chạy trên máy
chủ của Netlify, giữ API key bí mật, app chỉ gửi yêu cầu qua cầu nối này.

Toàn bộ quá trình mất khoảng 10 phút, không cần biết lập trình.

---

## Bước 1 — Lấy API key của Anthropic (Claude)

1. Vào **https://console.anthropic.com** → đăng ký / đăng nhập.
2. Vào mục **API Keys** → bấm **Create Key** → đặt tên bất kỳ (VD: "KienThinhQuote").
3. Copy đoạn key hiện ra (dạng `sk-ant-...`) — **chỉ hiện 1 lần**, lưu tạm vào Notepad.
4. Lưu ý: cần nạp tối thiểu 1 khoản tiền nhỏ vào tài khoản Anthropic (mục Billing) để
   API key hoạt động — chi phí mỗi lần dùng AI Assistant rất thấp (dưới 1.000đ/lần).

## Bước 2 — Tạo 1 site Netlify mới cho app này (nếu chưa có)

Nếu bạn **đã** deploy Kiên Thịnh Quote lên Netlify rồi thì bỏ qua, dùng lại đúng site đó.
Nếu đang dùng GitHub Pages, bạn nên chuyển app này sang Netlify (Netlify Functions không
chạy được trên GitHub Pages):

1. Vào **https://app.netlify.com** → đăng nhập bằng tài khoản đang dùng cho site quản lý
   hợp đồng.
2. Bấm **Add new site → Deploy manually**.
3. Kéo thả file `KienThinhQuote_Drive.html` (bản mới nhất) vào — Netlify sẽ tự đặt tên
   file thành `index.html` nếu cần, hoặc bạn đổi tên file thành `index.html` trước khi
   kéo vào cho chắc chắn.
4. Ghi lại đường link Netlify cấp cho bạn, ví dụ: `https://kienthinh-quote.netlify.app`

## Bước 3 — Thêm file "cầu nối" vào site

Netlify cần thấy file `ai-assist.js` nằm đúng trong thư mục `netlify/functions/` ngay
trong gói bạn deploy:

1. Trên máy tính, tạo 1 thư mục trống, ví dụ đặt tên `kienthinh-quote-deploy`.
2. Bên trong đó, tạo cấu trúc thư mục **đúng như sau**:
   ```
   kienthinh-quote-deploy/
   ├── index.html                      ← đổi tên KienThinhQuote_Drive.html thành index.html, để đây
   └── netlify/
       └── functions/
           └── ai-assist.js            ← file mình gửi kèm
   ```
3. Vào Netlify → chọn site vừa tạo ở Bước 2 → mục **Deploys** → kéo thả **toàn bộ thư mục**
   `kienthinh-quote-deploy` vào ô "Drag and drop your site output folder here".

> 💡 Nếu bạn đang deploy qua GitHub repo (không phải kéo-thả), chỉ cần commit đúng 2 file
> trên vào đúng vị trí trong repo rồi push lên — Netlify tự deploy lại.

## Bước 4 — Khai báo API key (an toàn, không lộ ra ngoài)

1. Trong Netlify, vào site vừa deploy → **Site configuration → Environment variables**.
2. Bấm **Add a variable**:
   - Key: `ANTHROPIC_API_KEY`
   - Value: dán API key đã copy ở Bước 1 (`sk-ant-...`)
3. Bấm **Save**.
4. Vào mục **Deploys** → bấm **Trigger deploy → Deploy site** để Netlify áp dụng biến
   môi trường mới (bắt buộc phải deploy lại sau khi thêm biến môi trường).

## Bước 5 — Lấy URL cầu nối và dán vào app

1. URL cầu nối của bạn sẽ có dạng:
   ```
   https://ten-site-cua-ban.netlify.app/.netlify/functions/ai-assist
   ```
   (thay `ten-site-cua-ban` bằng tên site thật của bạn ở Bước 2)
2. Mở app Kiên Thịnh Quote → **Cài đặt → ✨ AI Sales Assistant**.
3. Dán URL trên vào ô **"URL AI Assistant (Netlify Function)"** → bấm **💾 Lưu**.
4. Bấm **🔌 Kiểm tra kết nối** — nếu hiện "✅ Kết nối thành công" là xong!

---

## Sau khi thiết lập xong, dùng ở đâu?

- **Danh mục SP** → thêm/sửa sản phẩm → nút "✨ AI viết mô tả"
- **Khách hàng** → mở chi tiết 1 khách hàng → nút "✨ Soạn email"
- **Tạo/Sửa báo giá** → mục Ghi chú thêm → nút "✨ Lời mở đầu" / "✨ Điều khoản TM"
- **Tạo/Sửa báo giá** → mục Danh sách hàng hóa → nút "✨ Tóm tắt RFQ" (dán yêu cầu của
  khách vào, AI tóm tắt lại thành gạch đầu dòng)

## Câu hỏi thường gặp

**Chi phí bao nhiêu?** Rất thấp — mỗi lần bấm nút AI tốn khoảng vài trăm đến dưới
1.000đ tuỳ độ dài nội dung. Bạn có thể theo dõi/giới hạn chi tiêu trong
console.anthropic.com → Billing.

**Không thấy nút AI đâu / bấm không có phản ứng?** Kiểm tra lại đã lưu đúng URL ở
Cài đặt → AI Sales Assistant chưa, và đã bấm "Kiểm tra kết nối" thành công chưa.

**Đổi API key sau này?** Chỉ cần vào lại Netlify → Environment variables → sửa giá trị
`ANTHROPIC_API_KEY` → Trigger deploy lại. Không cần đổi gì trong app.
